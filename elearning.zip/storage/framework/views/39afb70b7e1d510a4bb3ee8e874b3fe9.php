<?php $__env->startSection('title', 'Dashboard Orang Tua'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-header">
    <div>
        <h1 class="page-title">Selamat Datang! 👋</h1>
        <p class="page-subtitle"><?php echo e(auth()->user()->name); ?> &nbsp;·&nbsp; <?php echo e(now()->isoFormat('dddd, D MMMM Y')); ?></p>
    </div>
</div>

<?php if($anakList->count() > 1): ?>
<div class="content-card" style="margin-bottom:16px;">
    <div class="card-body" style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
        <span style="font-size:13px;color:var(--text-secondary);font-weight:600;">Pilih anak:</span>
        <?php $__currentLoopData = $anakList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anak): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="?anak=<?php echo e($anak->id); ?>"
           class="btn btn-sm <?php echo e(($anakUtama?->id==$anak->id) ? 'btn-primary' : ''); ?>"
           style="<?php echo e(($anakUtama?->id!=$anak->id) ? 'background:var(--bg);color:var(--text-secondary);border:1px solid var(--border);' : ''); ?>">
            <?php echo e($anak->nama_lengkap); ?>

        </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php endif; ?>

<?php if($anakUtama): ?>

<div class="content-card" style="margin-bottom:24px;">
    <div class="card-body" style="display:flex;align-items:center;gap:16px;">
        <div class="user-avatar" style="width:56px;height:56px;font-size:20px;border-radius:14px;">
            <?php echo e(strtoupper(substr($anakUtama->nama_lengkap,0,1))); ?>

        </div>
        <div>
            <div style="font-size:18px;font-weight:800;color:var(--text-primary);"><?php echo e($anakUtama->nama_lengkap); ?></div>
            <div style="font-size:13px;color:var(--text-muted);">NISN: <?php echo e($anakUtama->nisn); ?> &nbsp;·&nbsp; Kelas <?php echo e($anakUtama->kelas->nama_kelas ?? '-'); ?></div>
        </div>
    </div>
</div>


<?php $abs = $absensiRekap[$anakUtama->id] ?? collect(); ?>
<div class="stats-grid" style="margin-bottom:24px;">
    <div class="stat-card stat-green">
        <div class="stat-icon"><i class="fas fa-check-circle"></i></div>
        <div><span class="stat-number"><?php echo e($abs['hadir']??0); ?></span><span class="stat-label">Hadir Bulan Ini</span></div>
    </div>
    <div class="stat-card stat-orange">
        <div class="stat-icon"><i class="fas fa-hospital"></i></div>
        <div><span class="stat-number"><?php echo e($abs['sakit']??0); ?></span><span class="stat-label">Sakit</span></div>
    </div>
    <div class="stat-card stat-blue">
        <div class="stat-icon"><i class="fas fa-file-lines"></i></div>
        <div><span class="stat-number"><?php echo e($abs['izin']??0); ?></span><span class="stat-label">Izin</span></div>
    </div>
    <div class="stat-card stat-purple">
        <div class="stat-icon"><i class="fas fa-user-times"></i></div>
        <div><span class="stat-number"><?php echo e($abs['alpha']??0); ?></span><span class="stat-label">Alpha</span></div>
    </div>
</div>

<div class="content-grid">
    
    <?php $tgs = $tugasRekap[$anakUtama->id] ?? []; ?>
    <div class="content-card">
        <div class="card-header">
            <h3><i class="fas fa-tasks" style="color:var(--primary);margin-right:8px;"></i>Tugas Anak</h3>
            <a href="<?php echo e(route('wali.tugas')); ?>" style="font-size:12px;color:var(--primary);font-weight:600;">Lihat detail</a>
        </div>
        <div class="card-body" style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
            <div style="background:var(--primary-light);padding:16px;border-radius:var(--radius-sm);text-align:center;">
                <div style="font-size:28px;font-weight:800;color:var(--primary);"><?php echo e($tgs['aktif']??0); ?></div>
                <div style="font-size:12px;color:var(--primary);font-weight:600;">Tugas Aktif</div>
            </div>
            <div style="background:#e6f4ea;padding:16px;border-radius:var(--radius-sm);text-align:center;">
                <div style="font-size:28px;font-weight:800;color:var(--secondary);"><?php echo e($tgs['dikumpul']??0); ?></div>
                <div style="font-size:12px;color:var(--secondary);font-weight:600;">Dikumpulkan</div>
            </div>
        </div>
    </div>

    
    <div class="content-card">
        <div class="card-header">
            <h3><i class="fas fa-calendar-check" style="color:var(--secondary);margin-right:8px;"></i>Absensi Terbaru</h3>
            <a href="<?php echo e(route('wali.kehadiran')); ?>" style="font-size:12px;color:var(--primary);font-weight:600;">Lihat semua</a>
        </div>
        <div class="table-responsive">
            <table class="data-table">
                <thead><tr><th>Tanggal</th><th>Status</th></tr></thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $absensiTerbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php $b=['hadir'=>'badge-green','sakit'=>'badge-light','izin'=>'badge-blue','alpha'=>'badge-light'][$a->status]??'badge-light'; ?>
                    <tr>
                        <td><?php echo e($a->tanggal->isoFormat('ddd, D MMM')); ?></td>
                        <td><span class="badge <?php echo e($b); ?>"><?php echo e(ucfirst($a->status)); ?></span></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="2" class="empty-row">Belum ada data.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>


<div class="content-card">
    <div class="card-header">
        <h3><i class="fas fa-bullhorn" style="color:var(--orange);margin-right:8px;"></i>Pengumuman</h3>
        <a href="<?php echo e(route('wali.pengumuman.index')); ?>" style="font-size:12px;color:var(--primary);font-weight:600;">Lihat semua</a>
    </div>
    <div>
        <?php $__empty_1 = true; $__currentLoopData = $pengumuman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <a href="<?php echo e(route('wali.pengumuman.show', $p)); ?>" class="announcement-item" style="padding:12px 20px;display:flex;gap:12px;text-decoration:none;">
            <div class="ann-icon"><i class="fas fa-megaphone"></i></div>
            <div>
                <div class="ann-title"><?php echo e($p->judul); ?></div>
                <div class="ann-meta"><?php echo e($p->kategori??'Umum'); ?> &nbsp;·&nbsp; <?php echo e($p->created_at->diffForHumans()); ?></div>
            </div>
        </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="empty-state">Tidak ada pengumuman.</div>
        <?php endif; ?>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.wali', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\PSI\Proyek Akhir\sistem-informasi-sd-negeri-sukorame-1\resources\views/wali/dashboard.blade.php ENDPATH**/ ?>
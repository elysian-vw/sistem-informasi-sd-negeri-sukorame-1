
<?php $__env->startSection('title', 'Kelola Galeri'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <div class="header-left">
        <h1 class="page-title">Kelola Galeri</h1>
        <p class="page-subtitle">Daftar dokumentasi foto dan video sekolah</p>
    </div>
    <div class="header-actions">
        <a href="<?php echo e(route('admin.galeri.create')); ?>" class="btn btn-primary">
            <i class="fas fa-plus"></i> Tambah Galeri
        </a>
    </div>
</div>

<?php if(session('success')): ?>
    <div class="alert alert-success">
        <i class="fas fa-check-circle"></i> <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<div class="content-card">
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th style="width: 50px;">No</th>
                    <th style="width: 150px;">Media</th>
                    <th>Judul & Deskripsi</th>
                    <th>Kategori</th>
                    <th>Tipe</th>
                    <th>Status</th>
                    <th style="width: 150px; text-align: center;">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $galeries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($idx + 1); ?></td>
                    <td>
                        <?php if($g->tipe == 'foto'): ?>
                            <img src="<?php echo e(asset('storage/' . $g->file_path)); ?>" class="media-preview" alt="Foto">
                        <?php else: ?>
                            <div class="video-preview">
                                <i class="fas fa-play-circle"></i> Video
                            </div>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div class="font-bold"><?php echo e($g->judul); ?></div>
                        <div class="text-xs text-gray-500 line-clamp-2"><?php echo e($g->deskripsi); ?></div>
                    </td>
                    <td>
                        <span class="badge badge-info"><?php echo e($g->kategori); ?></span>
                    </td>
                    <td>
                        <span class="badge <?php echo e($g->tipe == 'foto' ? 'badge-primary' : 'badge-warning'); ?>">
                            <?php echo e(ucfirst($g->tipe)); ?>

                        </span>
                    </td>
                    <td>
                        <span class="badge <?php echo e($g->is_published ? 'badge-success' : 'badge-secondary'); ?>">
                            <?php echo e($g->is_published ? 'Published' : 'Draft'); ?>

                        </span>
                    </td>
                    <td class="text-center">
                        <div class="table-actions">
                            <a href="<?php echo e(route('admin.galeri.edit', $g->id)); ?>" class="btn-icon btn-edit" title="Edit">
                                <i class="fas fa-edit"></i>
                            </a>
                            <form action="<?php echo e(route('admin.galeri.destroy', $g->id)); ?>" method="POST" onsubmit="return confirm('Hapus item galeri ini?')" style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn-icon btn-delete" title="Hapus">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7" class="text-center py-8">Belum ada data galeri.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<style>
.media-preview {
    width: 120px;
    height: 80px;
    object-fit: cover;
    border-radius: 8px;
    border: 1px solid #e5e7eb;
}
.video-preview {
    width: 120px;
    height: 80px;
    background: #f3f4f6;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    border-radius: 8px;
    color: #4b5563;
    font-size: 12px;
    gap: 4px;
}
.video-preview i { font-size: 20px; }
.badge {
    padding: 4px 10px;
    border-radius: 999px;
    font-size: 11px;
    font-weight: 600;
}
.badge-info { background: #eff6ff; color: #1d4ed8; }
.badge-primary { background: #eef2ff; color: #4338ca; }
.badge-warning { background: #fffbeb; color: #d97706; }
.badge-success { background: #f0fdf4; color: #15803d; }
.badge-secondary { background: #f9fafb; color: #6b7280; }

.table-actions { display: flex; justify-content: center; gap: 8px; }
.btn-icon {
    width: 32px;
    height: 32px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 8px;
    border: none;
    cursor: pointer;
    transition: all 0.2s;
}
.btn-edit { background: #eff6ff; color: #2563eb; }
.btn-edit:hover { background: #dbeafe; }
.btn-delete { background: #fef2f2; color: #dc2626; }
.btn-delete:hover { background: #fee2e2; }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\PSI\Proyek Akhir\sistem-informasi-sd-negeri-sukorame-1\resources\views/admin/galeri/index.blade.php ENDPATH**/ ?>
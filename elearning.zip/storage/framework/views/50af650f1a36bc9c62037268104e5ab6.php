<?php $__env->startSection('title', 'Penilaian Tugas'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h1 class="page-title">Penilaian Tugas</h1>
    <p class="page-subtitle">Pilih tugas untuk dinilai</p>
</div>

<div class="content-card">
    <div class="table-responsive">
        <table class="data-table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Judul Tugas</th>
                    <th>Mata Pelajaran</th>
                    <th>Kelas</th>
                    <th>Deadline</th>
                    <th style="text-align:center;">Terkumpul</th>
                    <th style="text-align:center;">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $daftarTugas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $total    = $t->kelas?->siswa()->count() ?? 0;
                    $kumpul   = $t->pengumpulan->count();
                    $dinilai  = $t->pengumpulan->whereNotNull('nilai')->count();
                ?>
                <tr>
                    <td style="color:var(--text-muted);font-size:12px;"><?php echo e($daftarTugas->firstItem() + $i); ?></td>
                    <td>
                        <div style="font-weight:600;font-size:13px;"><?php echo e($t->judul); ?></div>
                        <div style="font-size:11px;color:var(--text-muted);">
                            <?php echo e($t->tipe === 'cbt' ? '📋 CBT' : '📁 Upload'); ?>

                        </div>
                    </td>
                    <td style="font-size:13px;"><?php echo e($t->mataPelajaran->nama ?? '—'); ?></td>
                    <td style="font-size:13px;"><?php echo e($t->kelas->nama_kelas ?? '—'); ?></td>
                    <td style="font-size:12px;color:<?php echo e(now()->gt($t->deadline) ? 'var(--danger)':'var(--text-secondary)'); ?>;">
                        <?php echo e($t->deadline?->format('d M Y') ?? '—'); ?>

                    </td>
                    <td style="text-align:center;">
                        <div style="font-size:13px;font-weight:700;color:var(--primary);"><?php echo e($kumpul); ?>/<?php echo e($total); ?></div>
                        <div style="font-size:11px;color:var(--text-muted);"><?php echo e($dinilai); ?> dinilai</div>
                    </td>
                    <td style="text-align:center;">
                        <a href="<?php echo e(route('guru.tugas.penilaian', $t)); ?>" class="btn-primary-action" style="font-size:12px;">
                            <i class="fas fa-marker"></i> Nilai
                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="7" style="text-align:center;padding:32px;color:var(--text-muted);">
                    Belum ada tugas aktif.
                </td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if($daftarTugas->hasPages()): ?>
    <div class="card-footer"><?php echo e($daftarTugas->links()); ?></div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.guru', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\PSI\Proyek Akhir\sistem-informasi-sd-negeri-sukorame-1\resources\views/guru/tugas/list-penilaian.blade.php ENDPATH**/ ?>
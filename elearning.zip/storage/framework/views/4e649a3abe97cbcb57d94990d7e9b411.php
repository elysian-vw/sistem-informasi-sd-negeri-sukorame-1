<?php $__env->startSection('title', $pengumuman->judul); ?>

<?php $__env->startSection('content'); ?>

<div class="page-header">
    <div>
        <h1 class="page-title">Pengumuman</h1>
        <p class="page-subtitle"><a href="<?php echo e(route('wali.pengumuman.index')); ?>" style="color:var(--primary);">Pengumuman</a> / Detail</p>
    </div>
    <a href="<?php echo e(route('wali.pengumuman.index')); ?>" class="btn" style="background:var(--bg);color:var(--text-secondary);border:1px solid var(--border);">
        <i class="fas fa-arrow-left"></i> Kembali
    </a>
</div>

<div class="content-card" style="max-width:760px;">
    <div class="card-body">
        <?php if($pengumuman->kategori): ?>
        <span class="badge badge-blue" style="margin-bottom:12px;display:inline-block;"><?php echo e($pengumuman->kategori); ?></span>
        <?php endif; ?>
        <h2 style="font-size:22px;font-weight:800;color:var(--text-primary);margin-bottom:12px;"><?php echo e($pengumuman->judul); ?></h2>
        <div style="font-size:12px;color:var(--text-muted);display:flex;gap:16px;margin-bottom:20px;padding-bottom:16px;border-bottom:1px solid var(--border);">
            <span><i class="fas fa-user"></i> <?php echo e($pengumuman->user->name); ?></span>
            <span><i class="fas fa-calendar"></i> <?php echo e($pengumuman->created_at->isoFormat('D MMMM Y, HH:mm')); ?></span>
        </div>
        <div style="font-size:14px;color:var(--text-primary);line-height:1.9;white-space:pre-line;"><?php echo e($pengumuman->isi); ?></div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.wali', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\PSI\Proyek Akhir\sistem-informasi-sd-negeri-sukorame-1\resources\views/wali/pengumuman/show.blade.php ENDPATH**/ ?>
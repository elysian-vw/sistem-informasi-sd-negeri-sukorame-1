
<?php $__env->startSection('title', 'Tambah Prestasi'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h1 class="page-title">Tambah Prestasi Baru</h1>
    <p class="page-subtitle">Tambah data capaian prestasi baru</p>
</div>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul class="mb-0">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<div class="content-card p-6">
    <form action="<?php echo e(route('admin.prestasi.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <div class="form-group mb-4">
            <label class="form-label">Siswa Pelaksana</label>
            <select name="siswa_id" class="form-control">
                <option value="">-- Atas Nama Sekolah --</option>
                <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($s->id); ?>" <?php echo e(old('siswa_id') == $s->id ? 'selected' : ''); ?>><?php echo e($s->user->name); ?> (Kelas <?php echo e($s->kelas->nama_kelas ?? ''); ?>)</option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <small class="text-gray-500">Pilih jika prestasi diraih perorangan/kelompok siswa. Kosongkan jika prestasi lembaga.</small>
        </div>

        <div class="form-group mb-4">
            <label class="form-label">Nama Lomba / Capaian <span class="text-danger">*</span></label>
            <input type="text" name="nama_lomba" class="form-control" value="<?php echo e(old('nama_lomba')); ?>" required placeholder="Contoh: Juara 1 Olimpiade Matematika">
        </div>

        <div class="form-group mb-4">
            <label class="form-label">Penyelenggara <span class="text-danger">*</span></label>
            <input type="text" name="penyelenggara" class="form-control" value="<?php echo e(old('penyelenggara')); ?>" required placeholder="Contoh: Dinas Pendidikan Kota Kediri">
        </div>

        <div class="form-row mb-4">
            <div class="form-group col-md-4">
                <label class="form-label">Tingkat <span class="text-danger">*</span></label>
                <select name="tingkat" class="form-control" required>
                    <option value="sekolah">Sekolah</option>
                    <option value="kecamatan">Kecamatan</option>
                    <option value="kota">Kota/Kabupaten</option>
                    <option value="provinsi">Provinsi</option>
                    <option value="nasional">Nasional</option>
                    <option value="internasional">Internasional</option>
                </select>
            </div>
            <div class="form-group col-md-4">
                <label class="form-label">Capaian / Juara <span class="text-danger">*</span></label>
                <select name="juara" class="form-control" required>
                    <option value="1">Juara 1</option>
                    <option value="2">Juara 2</option>
                    <option value="3">Juara 3</option>
                    <option value="harapan_1">Harapan 1</option>
                    <option value="harapan_2">Harapan 2</option>
                    <option value="harapan_3">Harapan 3</option>
                    <option value="finalis">Finalis</option>
                    <option value="peserta">Peserta</option>
                </select>
            </div>
            <div class="form-group col-md-4">
                <label class="form-label">Tanggal Pelaksanaan <span class="text-danger">*</span></label>
                <input type="date" name="tanggal" class="form-control" value="<?php echo e(old('tanggal', date('Y-m-d'))); ?>" required>
            </div>
        </div>

        <div class="form-row mb-4">
            <div class="form-group col-md-6">
                <label class="form-label">Bidang</label>
                <input type="text" name="bidang" class="form-control" value="<?php echo e(old('bidang')); ?>" placeholder="Contoh: Olahraga, Seni, Akademik">
            </div>
            <div class="form-group col-md-6">
                <label class="form-label">Foto Dokumentasi</label>
                <input type="file" name="foto" class="form-control" accept="image/*">
                <small class="text-gray-500">Maksimal 2MB.</small>
            </div>
        </div>

        <div class="form-group mb-4">
            <label class="form-label">Keterangan</label>
            <textarea name="keterangan" class="form-control" rows="3"><?php echo e(old('keterangan')); ?></textarea>
        </div>

        <div class="form-group mb-4">
            <label class="inline-flex items-center">
                <input type="checkbox" name="is_published" value="1" class="form-checkbox" <?php echo e(old('is_published', '1') == '1' ? 'checked' : ''); ?>>
                <span class="ml-2">Tampilkan di Website</span>
            </label>
        </div>

        <div class="form-actions mt-6">
            <input type="hidden" name="is_published" value="0"> 
            <button type="submit" class="btn btn-primary">Simpan</button>
            <a href="<?php echo e(route('admin.prestasi.index')); ?>" class="btn btn-secondary">Batal</a>
        </div>
    </form>
</div>

<script>
// Fix for checkbox when not checked
document.querySelector('form').addEventListener('submit', function() {
    if(!document.querySelector('input[name="is_published"]').checked) {
        let input = document.createElement('input');
        input.type = 'hidden';
        input.name = 'is_published';
        input.value = '0';
        this.appendChild(input);
    }
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\PSI\Proyek Akhir\sistem-informasi-sd-negeri-sukorame-1\resources\views/admin/prestasi/create.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Kelola Soal — ' . $tugas->judul); ?>

<?php $__env->startSection('content'); ?>

<div class="page-header">
    <div style="display:flex;align-items:center;gap:12px;">
        <a href="<?php echo e(route('guru.tugas.index')); ?>" class="btn-back"><i class="fas fa-arrow-left"></i></a>
        <div>
            <h1 class="page-title">Kelola Soal CBT</h1>
            <p class="page-subtitle">
                <a href="<?php echo e(route('guru.tugas.index')); ?>">Tugas</a>
                &nbsp;/&nbsp; <?php echo e(Str::limit($tugas->judul, 40)); ?>

                &nbsp;·&nbsp; <?php echo e($tugas->kelas->nama_kelas ?? '-'); ?>

            </p>
        </div>
    </div>
    <div style="display:flex;gap:8px;">
        <a href="<?php echo e(route('guru.tugas.penilaian', $tugas)); ?>"
           class="btn btn-sm" style="background:#f3e5f5;color:var(--purple);border:1px solid #e1bee7;">
            <i class="fas fa-star"></i> Lihat Hasil
        </a>
    </div>
</div>

<?php if(session('success')): ?>
<div class="alert-success-toast"><i class="fas fa-check-circle"></i> <?php echo e(session('success')); ?></div>
<?php endif; ?>
<?php if(session('error')): ?>
<div class="alert alert-danger"><i class="fas fa-circle-exclamation"></i> <?php echo e(session('error')); ?></div>
<?php endif; ?>


<div style="display:flex;gap:12px;margin-bottom:20px;flex-wrap:wrap;">
    <div class="stat-card stat-purple" style="flex:1;min-width:140px;">
        <div class="stat-icon"><i class="fas fa-circle-question"></i></div>
        <div>
            <span class="stat-number"><?php echo e($pertanyaans->count()); ?></span>
            <span class="stat-label">Total Soal</span>
        </div>
    </div>
    <div class="stat-card stat-blue" style="flex:1;min-width:140px;">
        <div class="stat-icon"><i class="fas fa-users"></i></div>
        <div>
            <span class="stat-number"><?php echo e($tugas->pengumpulan->count()); ?></span>
            <span class="stat-label">Sudah Mengerjakan</span>
        </div>
    </div>
    <div class="stat-card stat-green" style="flex:1;min-width:140px;">
        <div class="stat-icon"><i class="fas fa-clock"></i></div>
        <div>
            <span class="stat-number"><?php echo e($tugas->deadline ? $tugas->deadline->format('d/m/Y') : '—'); ?></span>
            <span class="stat-label">Deadline</span>
        </div>
    </div>
</div>

<div style="display:grid;grid-template-columns:1fr 380px;gap:20px;align-items:start;">

    
    <div>
        <div class="content-card">
            <div class="card-header">
                <h3><i class="fas fa-list-check" style="color:var(--purple);margin-right:8px;"></i>Daftar Soal</h3>
            </div>

            <?php $__empty_1 = true; $__currentLoopData = $pertanyaans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="soal-card" id="soal-<?php echo e($p->id); ?>"
                 style="border-bottom:1px solid var(--border);padding:16px 20px;position:relative;">

                <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px;">
                    <div style="flex:1;">
                        <div style="font-size:12px;font-weight:700;color:var(--purple);margin-bottom:6px;">
                            Soal <?php echo e($i + 1); ?>

                        </div>
                        <p style="margin:0 0 8px;font-size:14px;font-weight:500;"><?php echo e($p->soal); ?></p>

                        <?php if($p->gambar_soal): ?>
                        <img src="<?php echo e(asset('storage/' . $p->gambar_soal)); ?>"
                             style="max-width:260px;border-radius:8px;border:1px solid var(--border);margin-bottom:10px;">
                        <?php endif; ?>

                        <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;font-size:13px;">
                            <?php $__currentLoopData = ['a','b','c','d']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div style="display:flex;align-items:center;gap:6px;padding:5px 8px;border-radius:6px;
                                        background:<?php echo e($p->jawaban_benar === strtoupper($opt) ? 'var(--success-light, #dcfce7)' : 'var(--bg)'); ?>;
                                        border:1px solid <?php echo e($p->jawaban_benar === strtoupper($opt) ? 'var(--success, #16a34a)' : 'var(--border)'); ?>;">
                                <span style="width:20px;height:20px;border-radius:50%;font-size:11px;font-weight:700;
                                             display:flex;align-items:center;justify-content:center;flex-shrink:0;
                                             background:<?php echo e($p->jawaban_benar === strtoupper($opt) ? 'var(--success, #16a34a)' : 'var(--border)'); ?>;
                                             color:<?php echo e($p->jawaban_benar === strtoupper($opt) ? '#fff' : 'var(--text-secondary)'); ?>;">
                                    <?php echo e(strtoupper($opt)); ?>

                                </span>
                                <?php echo e($p->{'pilihan_' . $opt}); ?>

                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                    
                    <div style="display:flex;flex-direction:column;gap:6px;flex-shrink:0;">
                        <button type="button" class="btn-icon btn-edit" title="Edit"
                                onclick="openEdit(<?php echo e($p->id); ?>)">
                            <i class="fas fa-pen"></i>
                        </button>
                        <form action="<?php echo e(route('guru.tugas.soal.destroy', [$tugas, $p])); ?>" method="POST">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button type="button" class="btn-icon btn-delete" title="Hapus"
                                    onclick="if(confirm('Hapus soal ini?')) this.closest('form').submit()">
                                <i class="fas fa-trash"></i>
                            </button>
                        </form>
                    </div>
                </div>

                
                <div id="editForm-<?php echo e($p->id); ?>" style="display:none;margin-top:14px;border-top:1px solid var(--border);padding-top:14px;">
                    <form action="<?php echo e(route('guru.tugas.soal.update', [$tugas, $p])); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                        <div class="form-group">
                            <label style="font-size:12px;">Pertanyaan</label>
                            <textarea name="soal" rows="2" class="form-control" required><?php echo e($p->soal); ?></textarea>
                        </div>
                        <div class="form-group">
                            <label style="font-size:12px;">Ganti Gambar (opsional)</label>
                            <input type="file" name="gambar_soal" class="form-control" accept="image/*">
                        </div>
                        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;">
                            <?php $__currentLoopData = ['a','b','c','d']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-group" style="margin-bottom:6px;">
                                <label style="font-size:12px;">Pilihan <?php echo e(strtoupper($opt)); ?></label>
                                <input type="text" name="pilihan_<?php echo e($opt); ?>"
                                       value="<?php echo e($p->{'pilihan_' . $opt}); ?>"
                                       class="form-control" required>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="form-group">
                            <label style="font-size:12px;">Jawaban Benar</label>
                            <select name="jawaban_benar" class="form-control" required>
                                <?php $__currentLoopData = ['A','B','C','D']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($opt); ?>" <?php if($p->jawaban_benar===$opt): echo 'selected'; endif; ?>><?php echo e($opt); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div style="display:flex;gap:8px;">
                            <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-save"></i> Simpan</button>
                            <button type="button" class="btn btn-sm" onclick="closeEdit(<?php echo e($p->id); ?>)"
                                    style="background:var(--bg);border:1px solid var(--border);">Batal</button>
                        </div>
                    </form>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div style="text-align:center;padding:40px;color:var(--text-muted);">
                <i class="fas fa-inbox" style="font-size:32px;display:block;margin-bottom:8px;opacity:.5;"></i>
                Belum ada soal. Tambahkan dari panel kanan.
            </div>
            <?php endif; ?>
        </div>
    </div>

    
    <div style="position:sticky;top:20px;">
        <div class="content-card">
            <div class="card-header">
                <h3><i class="fas fa-plus" style="color:var(--purple);margin-right:8px;"></i>Tambah Soal Baru</h3>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('guru.tugas.soal.store', $tugas)); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <div class="form-group">
                        <label style="font-size:12px;">Pertanyaan <span style="color:var(--danger);">*</span></label>
                        <textarea name="soal" rows="3" class="form-control"
                                  placeholder="Tulis pertanyaan..." required></textarea>
                    </div>

                    <div class="form-group">
                        <label style="font-size:12px;">Gambar Soal (opsional)</label>
                        <input type="file" name="gambar_soal" class="form-control" accept="image/*">
                    </div>

                    <?php $__currentLoopData = ['a','b','c','d']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-group" style="margin-bottom:8px;">
                        <label style="font-size:12px;">Pilihan <?php echo e(strtoupper($opt)); ?> <span style="color:var(--danger);">*</span></label>
                        <input type="text" name="pilihan_<?php echo e($opt); ?>" class="form-control"
                               placeholder="Isi pilihan <?php echo e(strtoupper($opt)); ?>" required>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="form-group">
                        <label style="font-size:12px;">Jawaban Benar <span style="color:var(--danger);">*</span></label>
                        <select name="jawaban_benar" class="form-control" required>
                            <option value="">-- Pilih --</option>
                            <option value="A">A</option>
                            <option value="B">B</option>
                            <option value="C">C</option>
                            <option value="D">D</option>
                        </select>
                    </div>

                    <button type="submit" class="btn btn-primary" style="width:100%;background:var(--purple);border-color:var(--purple);">
                        <i class="fas fa-plus"></i> Tambah Soal
                    </button>
                </form>
            </div>
        </div>
    </div>

</div>

<?php $__env->startPush('scripts'); ?>
<script>
function openEdit(id) {
    document.querySelectorAll('[id^="editForm-"]').forEach(el => el.style.display = 'none');
    document.getElementById('editForm-' + id).style.display = '';
    document.getElementById('soal-' + id).scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}
function closeEdit(id) {
    document.getElementById('editForm-' + id).style.display = 'none';
}
</script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.guru', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\PSI\Proyek Akhir\sistem-informasi-sd-negeri-sukorame-1\resources\views/guru/tugas/soal.blade.php ENDPATH**/ ?>
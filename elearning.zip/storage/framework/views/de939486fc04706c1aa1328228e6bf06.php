
<?php $__env->startSection('title', 'Tambah Anggota Komite'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h1 class="page-title">Tambah Anggota Komite</h1>
    <p class="page-subtitle">Tambah pengurus komite sekolah baru</p>
</div>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul class="mb-0">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<div class="content-card p-6">
    <form action="<?php echo e(route('admin.komite.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="form-group mb-4">
            <label class="form-label">Nama Lengkap <span class="text-danger">*</span></label>
            <input type="text" name="nama" class="form-control" value="<?php echo e(old('nama')); ?>" required>
        </div>

        <div class="form-row mb-4">
            <div class="form-group col-md-6">
                <label class="form-label">Jabatan <span class="text-danger">*</span></label>
                <input type="text" name="jabatan" class="form-control" value="<?php echo e(old('jabatan')); ?>" required placeholder="Contoh: Ketua Komite, Sekretaris">
            </div>
            <div class="form-group col-md-6">
                <label class="form-label">Unsur <span class="text-danger">*</span></label>
                <input type="text" name="unsur" class="form-control" value="<?php echo e(old('unsur', 'Orang Tua Siswa')); ?>" required>
            </div>
        </div>

        <div class="form-row mb-4">
            <div class="form-group col-md-6">
                <label class="form-label">Nomor Telepon</label>
                <input type="text" name="telepon" class="form-control" value="<?php echo e(old('telepon')); ?>">
            </div>
            <div class="form-group col-md-6">
                <label class="form-label">Urutan Tampil</label>
                <input type="number" name="urutan" class="form-control" value="<?php echo e(old('urutan', 0)); ?>">
            </div>
        </div>

        <div class="form-group mb-4">
            <label class="form-label">Status</label>
            <select name="aktif" class="form-control" required>
                <option value="1" <?php echo e(old('aktif', '1') == '1' ? 'selected' : ''); ?>>Aktif</option>
                <option value="0" <?php echo e(old('aktif') == '0' ? 'selected' : ''); ?>>Nonaktif</option>
            </select>
        </div>

        <div class="form-actions mt-6">
            <button type="submit" class="btn btn-primary">Simpan</button>
            <a href="<?php echo e(route('admin.komite.index')); ?>" class="btn btn-secondary">Batal</a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\PSI\Proyek Akhir\sistem-informasi-sd-negeri-sukorame-1\resources\views/admin/komite/create.blade.php ENDPATH**/ ?>
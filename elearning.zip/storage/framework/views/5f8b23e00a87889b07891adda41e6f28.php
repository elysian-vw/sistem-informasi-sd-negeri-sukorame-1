<?php $__env->startSection('title', 'Dashboard Guru'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-header">
    <div>
        <h1 class="page-title">Dashboard Guru</h1>
        <p class="page-subtitle">Selamat datang, <?php echo e(auth()->user()->name); ?>! &nbsp;·&nbsp; <?php echo e(now()->isoFormat('dddd, D MMMM Y')); ?></p>
    </div>
</div>


<div class="stats-grid">
    <div class="stat-card stat-green">
        <div class="stat-icon"><i class="fas fa-user-check"></i></div>
        <div>
            <span class="stat-number"><?php echo e($absensiHariIni['hadir'] ?? 0); ?></span>
            <span class="stat-label">Hadir Hari Ini</span>
        </div>
    </div>
    <div class="stat-card stat-orange">
        <div class="stat-icon"><i class="fas fa-user-times"></i></div>
        <div>
            <span class="stat-number"><?php echo e($absensiHariIni['alpha'] ?? 0); ?></span>
            <span class="stat-label">Alpha Hari Ini</span>
        </div>
    </div>
    <div class="stat-card stat-blue">
        <div class="stat-icon"><i class="fas fa-file-pen"></i></div>
        <div>
            <span class="stat-number"><?php echo e($tugasAktif->count()); ?></span>
            <span class="stat-label">Tugas Aktif</span>
        </div>
    </div>
    <div class="stat-card stat-purple">
        <div class="stat-icon"><i class="fas fa-book-open"></i></div>
        <div>
            <span class="stat-number"><?php echo e($materiTerbaru->count()); ?></span>
            <span class="stat-label">Total Materi</span>
        </div>
    </div>
</div>


<div class="content-card" style="margin-bottom:24px;">
    <div class="card-header">
        <h3><i class="fas fa-calendar-day" style="color:var(--primary);margin-right:8px;"></i>Jadwal Hari Ini</h3>
        <a href="<?php echo e(route('guru.jadwal.index')); ?>" style="font-size:12px;color:var(--primary);font-weight:600;">Lihat semua</a>
    </div>
    <div class="table-responsive">
        <table class="data-table">
            <thead>
                <tr>
                    <th style="width:50px;">Jam</th>
                    <th>Mata Pelajaran</th>
                    <th>Waktu</th>
                    <th>Ruangan</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $jadwalHariIni; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td style="text-align:center;font-weight:700;"><?php echo e($j->jam_ke); ?></td>
                    <td>
                        <div style="font-weight:600;"><?php echo e($j->mataPelajaran->nama ?? '-'); ?></div>
                        <div style="font-size:11px;color:var(--text-muted);"><?php echo e($j->mataPelajaran->jenis ?? ''); ?></div>
                    </td>
                    <td style="font-size:13px;white-space:nowrap;">
                        <?php echo e(\Carbon\Carbon::parse($j->waktu_mulai)->format('H:i')); ?> –
                        <?php echo e(\Carbon\Carbon::parse($j->waktu_selesai)->format('H:i')); ?>

                    </td>
                    <td style="font-size:13px;"><?php echo e($j->ruangan ?? '-'); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4" class="empty-row">
                        <i class="fas fa-calendar-check" style="display:block;font-size:20px;margin-bottom:6px;opacity:.4;"></i>
                        Tidak ada jadwal hari ini.
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="content-grid" style="margin-bottom:24px;">
    
    <div class="content-card">
        <div class="card-header">
            <h3><i class="fas fa-chart-bar" style="color:var(--primary);margin-right:8px;"></i>Kehadiran 7 Hari Terakhir</h3>
            <span style="font-size:12px;color:var(--text-muted);">7 hari terakhir</span>
        </div>
        <div class="card-body">
            <canvas id="absensiChart" height="120"></canvas>
        </div>
    </div>

    
    <div class="content-card">
        <div class="card-header">
            <h3><i class="fas fa-bullhorn" style="color:var(--orange);margin-right:8px;"></i>Pengumuman</h3>
        </div>
        <div class="card-body" style="padding:0;">
            <?php $__empty_1 = true; $__currentLoopData = $pengumuman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="announcement-item" style="padding:12px 20px;">
                <div class="ann-icon"><i class="fas fa-megaphone"></i></div>
                <div>
                    <div class="ann-title"><?php echo e($p->judul); ?></div>
                    <div class="ann-meta"><?php echo e($p->created_at->diffForHumans()); ?> &nbsp;·&nbsp; <?php echo e($p->kategori ?? 'Umum'); ?></div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="empty-state">Tidak ada pengumuman.</div>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="content-grid">
    
    <div class="content-card">
        <div class="card-header">
            <h3><i class="fas fa-tasks" style="color:var(--primary);margin-right:8px;"></i>Tugas Aktif</h3>
            <a href="<?php echo e(route('guru.tugas.index')); ?>" style="font-size:12px;color:var(--primary);font-weight:600;">Lihat semua</a>
        </div>
        <div class="table-responsive">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Judul</th>
                        <th>Kelas</th>
                        <th>Terkumpul</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $tugasAktif; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <a href="<?php echo e(route('guru.tugas.show', $t)); ?>" style="font-weight:600;color:var(--primary);"><?php echo e($t->judul); ?></a>
                            <div style="font-size:11px;color:var(--text-muted);"><?php echo e($t->mataPelajaran->nama ?? '-'); ?></div>
                        </td>
                        <td><?php echo e($t->kelas->nama_kelas ?? '-'); ?></td>
                        <td><span class="badge badge-blue"><?php echo e($t->pengumpulan->count()); ?> siswa</span></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="3" class="empty-row">Belum ada tugas aktif.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    
    <div class="content-card">
        <div class="card-header">
            <h3><i class="fas fa-comments" style="color:var(--secondary);margin-right:8px;"></i>Diskusi Terbaru</h3>
            <a href="<?php echo e(route('guru.forum.index')); ?>" style="font-size:12px;color:var(--primary);font-weight:600;">Lihat semua</a>
        </div>
        <div class="card-body" style="padding:0;">
            <?php $__empty_1 = true; $__currentLoopData = $diskusiTerbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <a href="<?php echo e(route('guru.forum.show', $d)); ?>" class="announcement-item" style="padding:12px 20px;display:flex;gap:12px;text-decoration:none;">
                <div class="ann-icon" style="background:#e6f4ea;color:var(--secondary);"><i class="fas fa-comments"></i></div>
                <div>
                    <div class="ann-title"><?php echo e($d->judul); ?></div>
                    <div class="ann-meta"><?php echo e($d->user->name); ?> &nbsp;·&nbsp; <?php echo e($d->komentar->count()); ?> komentar &nbsp;·&nbsp; <?php echo e($d->created_at->diffForHumans()); ?></div>
                </div>
            </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="empty-state">Belum ada diskusi.</div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    new Chart(document.getElementById('absensiChart'), {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($absensiLabels, 15, 512) ?>,
            datasets: [{
                label: 'Hadir',
                data: <?php echo json_encode($absensiData, 15, 512) ?>,
                backgroundColor: 'rgba(26,115,232,0.75)',
                borderRadius: 6,
            }]
        },
        options: {
            plugins: { legend: { display: false } },
            scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } } }
        }
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.guru', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\PSI\Proyek Akhir\sistem-informasi-sd-negeri-sukorame-1\resources\views/guru/dashboard.blade.php ENDPATH**/ ?>
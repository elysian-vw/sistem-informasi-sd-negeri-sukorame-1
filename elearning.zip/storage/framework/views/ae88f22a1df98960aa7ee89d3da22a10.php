
<?php $__env->startSection('title', 'Edit Tugas'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-header">
    <div>
        <h1 class="page-title">Edit Tugas</h1>
        <p class="page-subtitle"><a href="<?php echo e(route('guru.tugas.index')); ?>" style="color:var(--primary);">Tugas</a> / Edit</p>
    </div>
</div>

<?php if($errors->any()): ?>
<div class="alert alert-danger"><i class="fas fa-circle-exclamation"></i>
    <div><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><div><?php echo e($e); ?></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div>
</div>
<?php endif; ?>

<div class="content-card" style="max-width:800px;">
    <div class="card-header">
        <h3><i class="fas fa-file-pen" style="color:var(--primary);margin-right:8px;"></i>Form Edit Tugas</h3>
    </div>
    <div class="card-body">
        <form action="<?php echo e(route('guru.tugas.update', $tugas)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            
            <div class="form-group">
                <label>Judul Tugas <span style="color:var(--danger);">*</span></label>
                <input type="text" name="judul" value="<?php echo e(old('judul', $tugas->judul)); ?>" class="form-control"
                       placeholder="Contoh: Latihan Soal Perkalian">
            </div>

            <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">
                <div class="form-group">
                    <label>Kelas <span style="color:var(--danger);">*</span></label>
                    <select name="kelas_id" class="form-control" style="background-color:#f8f9fa;cursor:not-allowed;pointer-events:none;" readonly>
                        <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($k->id); ?>" selected>Kelas <?php echo e($k->nama_kelas); ?> (Kelas Anda)</option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <small style="color:var(--text-muted);font-size:11px;margin-top:4px;display:block;">* Terkunci pada kelas yang Anda ajar.</small>
                </div>

                <div class="form-group">
                    <label>Mata Pelajaran <span style="color:var(--danger);">*</span></label>
                    <select name="mata_pelajaran_id" class="form-control">
                        <option value="">-- Pilih Mapel --</option>
                        <?php $__currentLoopData = $mapel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($m->id); ?>" <?php if(old('mata_pelajaran_id', $tugas->mata_pelajaran_id) == $m->id): echo 'selected'; endif; ?>><?php echo e($m->nama); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label>Deskripsi / Petunjuk Tugas</label>
                <textarea name="deskripsi" rows="4" class="form-control"
                          placeholder="Tuliskan petunjuk pengerjaan tugas..."><?php echo e(old('deskripsi', $tugas->deskripsi)); ?></textarea>
            </div>

            <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">
                <div class="form-group">
                    <label>Deadline</label>
                    <input type="datetime-local" name="deadline"
                           value="<?php echo e(old('deadline', $tugas->deadline?->format('Y-m-d\TH:i'))); ?>"
                           class="form-control">
                </div>
                <div class="form-group">
                    <label>Status</label>
                    <select name="status" class="form-control">
                        <option value="aktif" <?php if(old('status', $tugas->status) == 'aktif'): echo 'selected'; endif; ?>>Aktif</option>
                        <option value="draft" <?php if(old('status', $tugas->status) == 'draft'): echo 'selected'; endif; ?>>Draft</option>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label>Lampiran File (opsional)</label>
                <?php if($tugas->file): ?>
                    <div style="margin-bottom:8px;padding:8px 12px;background:var(--bg);border:1px solid var(--border);border-radius:8px;font-size:13px;">
                        <i class="fas fa-paperclip" style="color:var(--primary);margin-right:6px;"></i>
                        File saat ini: <a href="<?php echo e(Storage::url($tugas->file)); ?>" target="_blank" style="color:var(--primary);">Lihat File</a>
                        <span style="color:var(--text-muted);margin-left:8px;">(Upload baru untuk mengganti)</span>
                    </div>
                <?php endif; ?>
                <input type="file" name="file" class="form-control">
                <small style="color:var(--text-muted);font-size:12px;margin-top:4px;display:block;">PDF, DOC, DOCX, ZIP. Maks 5 MB.</small>
            </div>

            <div style="display:flex;gap:10px;margin-top:20px;">
                <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Update Tugas</button>
                <a href="<?php echo e(route('guru.tugas.index')); ?>" class="btn"
                style="background:var(--bg);color:var(--text-secondary);border:1px solid var(--border);">Batal</a>
                
                
                <?php if($tugas->isCbt()): ?>
                <a href="<?php echo e(route('guru.tugas.soal', $tugas)); ?>" class="btn"
                style="background:#f3e5f5;color:var(--purple);border:1px solid #e1bee7;">
                    <i class="fas fa-list-check"></i> Kelola Soal CBT
                </a>
                <?php endif; ?>
            </div>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.guru', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\PSI\Proyek Akhir\sistem-informasi-sd-negeri-sukorame-1\resources\views/guru/tugas/edit.blade.php ENDPATH**/ ?>
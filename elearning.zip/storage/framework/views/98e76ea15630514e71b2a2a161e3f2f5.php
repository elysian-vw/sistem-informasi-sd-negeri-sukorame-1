<?php $__env->startSection('title', 'Data Siswa'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <div>
        <h1 class="page-title">Data Siswa</h1>
        <p class="page-subtitle">Kelola data seluruh siswa</p>
    </div>
    <a href="<?php echo e(route('admin.siswa.create')); ?>" class="btn btn-primary">
        <i class="fas fa-plus"></i> Tambah Siswa
    </a>
</div>

<div class="content-card">
    <div class="table-toolbar">
        <form method="GET" action="<?php echo e(route('admin.siswa.index')); ?>" style="display: flex; gap: 12px; width: 100%; flex-wrap: wrap;">
            <div class="search-box">
                <i class="fas fa-search"></i>
                <input type="text" name="cari" value="<?php echo e(request('cari')); ?>" placeholder="Cari nama / NISN..." class="form-control">
            </div>
            <div style="width: 220px;">
                <select name="kelas_id" onchange="this.form.submit()" class="form-control">
                    <option value="">Semua Kelas</option>
                    <?php $__currentLoopData = $kelasList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($k->id); ?>" <?php echo e(request('kelas_id') == $k->id ? 'selected' : ''); ?>>
                            Kelas <?php echo e($k->nama_kelas); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div style="display: flex; gap: 8px;">
                <button type="submit" class="btn btn-primary">Cari</button>
                <?php if(request('cari') || request('kelas_id')): ?>
                    <a href="<?php echo e(route('admin.siswa.index')); ?>" class="btn" style="background: #f1f5f9; border: 1px solid #cbd5e1; color: #475569;">Reset</a>
                <?php endif; ?>
            </div>
        </form>
    </div>

    <div class="table-responsive">
        <table class="data-table">
            <thead>
                <tr>
                    <th>No</th>
                    <th>NISN</th>
                    <th>Nama Lengkap</th>
                    <th>Kelas</th>
                    <th>Jenis Kelamin</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($siswa->firstItem() + $i); ?></td>
                    <td><span class="badge badge-light"><?php echo e($s->nisn); ?></span></td>
                    <td>
                        <div class="user-cell">
                            <div class="avatar"><?php echo e(substr($s->nama_lengkap, 0, 1)); ?></div>
                            <div style="font-weight: 600;"><?php echo e($s->nama_lengkap); ?></div>
                        </div>
                    </td>
                    <td><?php echo e($s->kelas->nama_kelas ?? '-'); ?></td>
                    <td>
                        <?php if($s->jenis_kelamin === 'L'): ?>
                            <span class="badge badge-blue">Laki-laki</span>
                        <?php else: ?>
                            <span class="badge badge-pink">Perempuan</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div class="action-btns">
                            <a href="<?php echo e(route('admin.siswa.edit', $s)); ?>" class="btn-icon btn-edit" title="Edit">
                                <i class="fas fa-pen"></i>
                            </a>
                            <form action="<?php echo e(route('admin.siswa.destroy', $s)); ?>" method="POST" onsubmit="return confirm('Hapus data siswa ini?')" style="margin: 0;">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn-icon btn-delete" title="Hapus">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" class="empty-row">Tidak ada data siswa.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="pagination-wrapper" style="display: flex; justify-content: space-between; align-items: center; padding: 16px 20px;">
        <div style="font-size: 13px; color: var(--text-secondary);">
            Menampilkan <?php echo e($siswa->firstItem() ?? 0); ?> - <?php echo e($siswa->lastItem() ?? 0); ?> dari total <?php echo e($siswa->total()); ?> data
        </div>
        <div>
            <?php echo e($siswa->appends(request()->query())->links('vendor.pagination.custom')); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\PSI\Proyek Akhir\sistem-informasi-sd-negeri-sukorame-1\resources\views/admin/siswa/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Daftar Materi'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-header">
    <div>
        <h1 class="page-title">Materi Pembelajaran</h1>
        <p class="page-subtitle">Kelola materi yang Anda ajarkan</p>
    </div>
    <a href="<?php echo e(route('guru.materi.create')); ?>" class="btn-primary-action">
        <i class="fas fa-plus"></i> Tambah Materi
    </a>
</div>

<?php if(session('success')): ?>
    <div class="alert-success-toast">
        <i class="fas fa-check-circle"></i> <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>


<div class="content-card" style="margin-bottom:20px;">
    <form method="GET" action="<?php echo e(route('guru.materi.index')); ?>" class="filter-bar">
        <div class="filter-group">
            <label class="filter-label"><i class="fas fa-book"></i> Mata Pelajaran</label>
            <select name="mata_pelajaran_id" class="filter-select" onchange="this.form.submit()">
                <option value="">Semua Mapel</option>
                <?php $__currentLoopData = $mapel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($mp->id); ?>" <?php echo e(request('mata_pelajaran_id') == $mp->id ? 'selected' : ''); ?>>
                        <?php echo e($mp->nama); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        
        <div class="filter-group">
            <label class="filter-label"><i class="fas fa-school"></i> Kelas</label>
            <select name="kelas_id" class="filter-select" onchange="this.form.submit()">
                <option value="">Semua Kelas</option>
                <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($k->id); ?>" <?php echo e(request('kelas_id') == $k->id ? 'selected' : ''); ?>>
                        <?php echo e($k->nama_kelas); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="filter-group">
            <label class="filter-label"><i class="fas fa-tag"></i> Tipe</label>
            <select name="tipe" class="filter-select" onchange="this.form.submit()">
                <option value="">Semua Tipe</option>
                <option value="file"  <?php echo e(request('tipe') == 'file'  ? 'selected' : ''); ?>>File Dokumen</option>
                <option value="link"  <?php echo e(request('tipe') == 'link'  ? 'selected' : ''); ?>>Tautan</option>
                <option value="video" <?php echo e(request('tipe') == 'video' ? 'selected' : ''); ?>>Video</option>
            </select>
        </div>
        
        <?php if(request()->hasAny(['mata_pelajaran_id','kelas_id','tipe'])): ?>
            <a href="<?php echo e(route('guru.materi.index')); ?>" class="btn-reset-filter">
                <i class="fas fa-times"></i> Reset
            </a>
        <?php endif; ?>
    </form>
</div>


<div class="content-card">
    <div class="table-responsive">
        <table class="data-table">
            <thead>
                <tr>
                    <th style="width:40px">#</th>
                    <th>Judul Materi</th>
                    <th>Mata Pelajaran</th>
                    <th>Kelas</th>
                    <th>Tipe</th>
                    <th>Tanggal</th>
                    <th style="text-align:center">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $materi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td style="color:var(--text-muted);font-size:13px;"><?php echo e($materi->firstItem() + $loop->index); ?></td>
                    <td>
                        <div style="font-weight:600;color:var(--text-dark);"><?php echo e($item->judul); ?></div>
                        <?php if($item->deskripsi): ?>
                            <div style="font-size:12px;color:var(--text-muted);margin-top:2px;">
                                <?php echo e(Str::limit($item->deskripsi, 60)); ?>

                            </div>
                        <?php endif; ?>
                    </td>
                    <td style="font-size:13px;"><?php echo e($item->mataPelajaran->nama ?? '-'); ?></td>
                    <td style="font-size:13px;"><?php echo e($item->kelas->nama_kelas ?? '-'); ?></td>
                    <td>
                        <?php
                            $tipeConfig = [
                                'file'  => ['icon' => 'fa-file-alt',    'class' => 'badge-blue',   'label' => 'File'],
                                'link'  => ['icon' => 'fa-link',        'class' => 'badge-purple', 'label' => 'Tautan'],
                                'video' => ['icon' => 'fa-play-circle', 'class' => 'badge-orange', 'label' => 'Video'],
                            ];
                            $cfg = $tipeConfig[$item->tipe] ?? ['icon'=>'fa-file','class'=>'badge-blue','label'=>strtoupper($item->tipe)];
                        ?>
                        <span class="badge <?php echo e($cfg['class']); ?>">
                            <i class="fas <?php echo e($cfg['icon']); ?>" style="margin-right:4px;"></i><?php echo e($cfg['label']); ?>

                        </span>
                    </td>
                    <td style="font-size:12px;color:var(--text-muted);">
                        <?php echo e($item->created_at->format('d M Y')); ?>

                    </td>
                    <td>
                        <div class="action-buttons">
                            <a href="<?php echo e(route('guru.materi.show', $item)); ?>" class="btn-action btn-view" title="Detail">
                                <i class="fas fa-eye"></i>
                            </a>
                            <a href="<?php echo e(route('guru.materi.edit', $item)); ?>" class="btn-action btn-edit" title="Edit">
                                <i class="fas fa-pencil-alt"></i>
                            </a>
                            <form action="<?php echo e(route('guru.materi.destroy', $item)); ?>" method="POST"
                                  onsubmit="return confirm('Yakin hapus materi ini?')" style="display:inline;">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn-action btn-delete" title="Hapus">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7" class="empty-row">
                        <div style="padding:40px 0;text-align:center;">
                            <i class="fas fa-book-open" style="font-size:36px;color:var(--text-muted);opacity:.4;margin-bottom:12px;display:block;"></i>
                            <div style="color:var(--text-muted);margin-bottom:8px;">Belum ada materi.</div>
                            <a href="<?php echo e(route('guru.materi.create')); ?>" style="color:var(--primary);font-weight:600;font-size:13px;">
                                + Tambah sekarang
                            </a>
                        </div>
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php if($materi->hasPages()): ?>
    <div style="padding:16px 20px;border-top:1px solid var(--border);">
        <?php echo e($materi->links()); ?>

    </div>
    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.guru', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\PSI\Proyek Akhir\sistem-informasi-sd-negeri-sukorame-1\resources\views/guru/materi/index.blade.php ENDPATH**/ ?>
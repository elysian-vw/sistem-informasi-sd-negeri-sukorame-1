<?php $__env->startSection('title', 'Raport'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <div>
        <h1 class="page-title">Raport</h1>
        <p class="page-subtitle">Lihat nilai raport anak Anda</p>
    </div>
</div>


<?php if($anakList->count() > 1): ?>
<div class="content-card" style="margin-bottom:16px;">
    <div class="card-body" style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
        <span style="font-size:13px;color:var(--text-secondary);font-weight:600;">Pilih anak:</span>
        <?php $__currentLoopData = $anakList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anak): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="?anak=<?php echo e($anak->id); ?>"
           class="btn btn-sm <?php echo e(($anakUtama?->id == $anak->id) ? 'btn-primary' : ''); ?>"
           style="<?php echo e(($anakUtama?->id != $anak->id) ? 'background:var(--bg);color:var(--text-secondary);border:1px solid var(--border);' : ''); ?>">
            <?php echo e($anak->nama_lengkap); ?>

        </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php endif; ?>


<?php if($anakUtama): ?>
<div class="content-card" style="margin-bottom:24px;">
    <div class="card-body" style="display:flex;align-items:center;gap:16px;">
        <div class="user-avatar" style="width:56px;height:56px;font-size:20px;border-radius:14px;">
            <?php echo e(strtoupper(substr($anakUtama->nama_lengkap, 0, 1))); ?>

        </div>
        <div>
            <div style="font-size:18px;font-weight:800;color:var(--text-primary);"><?php echo e($anakUtama->nama_lengkap); ?></div>
            <div style="font-size:13px;color:var(--text-muted);">
                NISN: <?php echo e($anakUtama->nisn); ?> &nbsp;·&nbsp; Kelas <?php echo e($anakUtama->kelas->nama_kelas ?? '-'); ?>

            </div>
        </div>
    </div>
</div>


<div class="content-card">
    <div class="card-header">
        <h3><i class="fas fa-book-open" style="color:var(--primary);margin-right:8px;"></i>Daftar Raport</h3>
    </div>
    <div class="table-responsive">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Tahun Ajaran</th>
                    <th>Semester</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $raportList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($r->tahun_ajaran); ?></td>
                    <td>Semester <?php echo e($r->semester); ?></td>
                    <td><span class="badge badge-green">Terbit</span></td>
                    <td>
                        <a href="<?php echo e(route('wali.raport.show', $r)); ?>" class="btn btn-sm btn-primary">
                            <i class="fas fa-eye"></i> Lihat
                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="4" class="empty-row">Belum ada raport yang diterbitkan.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.wali', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\PSI\Proyek Akhir\sistem-informasi-sd-negeri-sukorame-1\resources\views/wali/raport/index.blade.php ENDPATH**/ ?>
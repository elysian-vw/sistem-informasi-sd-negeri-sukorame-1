
<?php $__env->startSection('title', 'Edit Prestasi'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h1 class="page-title">Edit Prestasi</h1>
    <p class="page-subtitle">Ubah data capaian prestasi</p>
</div>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul class="mb-0">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<div class="content-card p-6">
    <form action="<?php echo e(route('admin.prestasi.update', $prestasi->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="form-group mb-4">
            <label class="form-label">Siswa Pelaksana</label>
            <select name="siswa_id" class="form-control">
                <option value="">-- Atas Nama Sekolah --</option>
                <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($s->id); ?>" <?php echo e(old('siswa_id', $prestasi->siswa_id) == $s->id ? 'selected' : ''); ?>><?php echo e($s->user->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="form-group mb-4">
            <label class="form-label">Nama Lomba / Capaian <span class="text-danger">*</span></label>
            <input type="text" name="nama_lomba" class="form-control" value="<?php echo e(old('nama_lomba', $prestasi->nama_lomba)); ?>" required>
        </div>

        <div class="form-group mb-4">
            <label class="form-label">Penyelenggara <span class="text-danger">*</span></label>
            <input type="text" name="penyelenggara" class="form-control" value="<?php echo e(old('penyelenggara', $prestasi->penyelenggara)); ?>" required>
        </div>

        <div class="form-row mb-4">
            <div class="form-group col-md-4">
                <label class="form-label">Tingkat <span class="text-danger">*</span></label>
                <select name="tingkat" class="form-control" required>
                    <?php $__currentLoopData = ['sekolah','kecamatan','kota','provinsi','nasional','internasional']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($t); ?>" <?php echo e(old('tingkat', $prestasi->tingkat) == $t ? 'selected' : ''); ?>><?php echo e(ucfirst($t)); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group col-md-4">
                <label class="form-label">Capaian / Juara <span class="text-danger">*</span></label>
                <select name="juara" class="form-control" required>
                    <?php $__currentLoopData = ['1','2','3','harapan_1','harapan_2','harapan_3','finalis','peserta']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($j); ?>" <?php echo e(old('juara', $prestasi->juara) == $j ? 'selected' : ''); ?>><?php echo e(str_replace('_', ' ', ucfirst($j))); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group col-md-4">
                <label class="form-label">Tanggal Pelaksanaan <span class="text-danger">*</span></label>
                <input type="date" name="tanggal" class="form-control" value="<?php echo e(old('tanggal', $prestasi->tanggal)); ?>" required>
            </div>
        </div>

        <div class="form-row mb-4">
            <div class="form-group col-md-6">
                <label class="form-label">Bidang</label>
                <input type="text" name="bidang" class="form-control" value="<?php echo e(old('bidang', $prestasi->bidang)); ?>">
            </div>
            <div class="form-group col-md-6">
                <label class="form-label">Foto Dokumentasi</label>
                <?php if($prestasi->foto): ?>
                    <div class="mb-2">
                        <img src="<?php echo e(asset('storage/' . $prestasi->foto)); ?>" class="img-thumbnail" style="max-height: 150px;">
                    </div>
                <?php endif; ?>
                <input type="file" name="foto" class="form-control" accept="image/*">
            </div>
        </div>

        <div class="form-group mb-4">
            <label class="form-label">Keterangan</label>
            <textarea name="keterangan" class="form-control" rows="3"><?php echo e(old('keterangan', $prestasi->keterangan)); ?></textarea>
        </div>

        <div class="form-group mb-4">
            <label class="inline-flex items-center">
                <input type="checkbox" name="is_published" value="1" class="form-checkbox" <?php echo e(old('is_published', $prestasi->is_published) ? 'checked' : ''); ?>>
                <span class="ml-2">Tampilkan di Website</span>
            </label>
        </div>

        <div class="form-actions mt-6">
            <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
            <a href="<?php echo e(route('admin.prestasi.index')); ?>" class="btn btn-secondary">Batal</a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\PSI\Proyek Akhir\sistem-informasi-sd-negeri-sukorame-1\resources\views/admin/prestasi/edit.blade.php ENDPATH**/ ?>
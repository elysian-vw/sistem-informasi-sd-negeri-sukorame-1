<?php $__env->startSection('title', 'Dashboard Siswa'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-header">
    <div>
        <h1 class="page-title">Halo, <?php echo e(auth()->user()->name); ?>! 👋</h1>
        <p class="page-subtitle"><?php echo e($siswa->kelas->nama_kelas ?? '-'); ?> &nbsp;·&nbsp; <?php echo e(now()->isoFormat('dddd, D MMMM Y')); ?></p>
    </div>
</div>


<div class="stats-grid">
    <div class="stat-card stat-green">
        <div class="stat-icon"><i class="fas fa-check-circle"></i></div>
        <div><span class="stat-number"><?php echo e($absensi['hadir'] ?? 0); ?></span><span class="stat-label">Hadir Bulan Ini</span></div>
    </div>
    <div class="stat-card stat-orange">
        <div class="stat-icon"><i class="fas fa-hospital"></i></div>
        <div><span class="stat-number"><?php echo e($absensi['sakit'] ?? 0); ?></span><span class="stat-label">Sakit</span></div>
    </div>
    <div class="stat-card stat-blue">
        <div class="stat-icon"><i class="fas fa-file-lines"></i></div>
        <div><span class="stat-number"><?php echo e($absensi['izin'] ?? 0); ?></span><span class="stat-label">Izin</span></div>
    </div>
    <div class="stat-card stat-purple">
        <div class="stat-icon"><i class="fas fa-user-times"></i></div>
        <div><span class="stat-number"><?php echo e($absensi['alpha'] ?? 0); ?></span><span class="stat-label">Alpha</span></div>
    </div>
</div>

<div class="content-grid">
    
    <div class="content-card">
        <div class="card-header">
            <h3><i class="fas fa-file-pen" style="color:var(--primary);margin-right:8px;"></i>Tugas Aktif</h3>
            <a href="<?php echo e(route('siswa.tugas.index')); ?>" style="font-size:12px;color:var(--primary);font-weight:600;">Lihat semua</a>
        </div>
        <div class="table-responsive">
            <table class="data-table">
                <thead><tr><th>Tugas</th><th>Mapel</th><th>Status</th></tr></thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $tugasAktif; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <a href="<?php echo e(route('siswa.tugas.show', $t)); ?>" style="font-weight:600;color:var(--primary);"><?php echo e($t->judul); ?></a>
                            <?php if($t->deadline): ?>
                            <div style="font-size:11px;color:<?php echo e($t->isTerlambat()?'var(--danger)':'var(--text-muted)'); ?>;">
                                <i class="fas fa-clock"></i> <?php echo e($t->deadline->format('d/m/Y')); ?>

                            </div>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($t->mataPelajaran->nama ?? '-'); ?></td>
                        <td>
                            <?php if($t->sudah_kumpul): ?>
                                <span class="badge badge-green">✓ Dikumpulkan</span>
                            <?php else: ?>
                                <span class="badge badge-light" style="color:var(--danger);">Belum</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="3" class="empty-row">Tidak ada tugas aktif.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    
    <div class="content-card">
        <div class="card-header">
            <h3><i class="fas fa-book-open" style="color:var(--secondary);margin-right:8px;"></i>Materi Terbaru</h3>
            <a href="<?php echo e(route('siswa.materi.index')); ?>" style="font-size:12px;color:var(--primary);font-weight:600;">Lihat semua</a>
        </div>
        <div style="padding:0;">
            <?php $__empty_1 = true; $__currentLoopData = $materiTerbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="announcement-item" style="padding:12px 20px;">
                <div class="ann-icon" style="background:#e6f4ea;color:var(--secondary);"><i class="fas fa-file-alt"></i></div>
                <div>
                    <div class="ann-title"><?php echo e($m->judul); ?></div>
                    <div class="ann-meta"><?php echo e($m->mataPelajaran->nama ?? '-'); ?> &nbsp;·&nbsp; <?php echo e($m->created_at->diffForHumans()); ?></div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="empty-state">Belum ada materi.</div>
            <?php endif; ?>
        </div>
    </div>
</div>


<div class="content-card">
    <div class="card-header">
        <h3><i class="fas fa-bullhorn" style="color:var(--orange);margin-right:8px;"></i>Pengumuman</h3>
    </div>
    <div>
        <?php $__empty_1 = true; $__currentLoopData = $pengumuman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="announcement-item" style="padding:12px 20px;">
            <div class="ann-icon"><i class="fas fa-megaphone"></i></div>
            <div>
                <div class="ann-title"><?php echo e($p->judul); ?></div>
                <div class="ann-meta"><?php echo e($p->created_at->diffForHumans()); ?> &nbsp;·&nbsp; <?php echo e($p->kategori ?? 'Umum'); ?></div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="empty-state">Tidak ada pengumuman.</div>
        <?php endif; ?>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.siswa', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\PSI\Proyek Akhir\sistem-informasi-sd-negeri-sukorame-1\resources\views/siswa/dashboard.blade.php ENDPATH**/ ?>
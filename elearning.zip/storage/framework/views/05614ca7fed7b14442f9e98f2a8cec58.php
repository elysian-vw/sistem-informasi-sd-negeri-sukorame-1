<?php $__env->startSection('title', 'Manajemen Tugas'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-header">
    <div>
        <h1 class="page-title">Manajemen Tugas</h1>
        <p class="page-subtitle">Buat dan kelola tugas untuk siswa</p>
    </div>
    <a href="<?php echo e(route('guru.tugas.create')); ?>" class="btn btn-primary">
        <i class="fas fa-plus"></i> Buat Tugas
    </a>
</div>

<div class="content-card">
    <div class="table-toolbar">
        <form method="GET" style="display:flex;gap:10px;flex-wrap:wrap;width:100%;">
            <select name="kelas_id" class="form-control" style="width:auto;">
                <option value="">Semua Kelas</option>
                <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($k->id); ?>" <?php if(request('kelas_id') == $k->id): echo 'selected'; endif; ?>><?php echo e($k->nama_kelas); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <select name="status" class="form-control" style="width:auto;">
                <option value="">Semua Status</option>
                <option value="aktif"   <?php if(request('status')=='aktif'): echo 'selected'; endif; ?>>Aktif</option>
                <option value="selesai" <?php if(request('status')=='selesai'): echo 'selected'; endif; ?>>Selesai</option>
                <option value="draft"   <?php if(request('status')=='draft'): echo 'selected'; endif; ?>>Draft</option>
            </select>
            <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-search"></i> Filter</button>
            <a href="<?php echo e(route('guru.tugas.index')); ?>" class="btn btn-sm" style="background:var(--bg);color:var(--text-secondary);border:1px solid var(--border);">Reset</a>
        </form>
    </div>

    <div class="table-responsive">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Judul Tugas</th>
                    <th>Kelas</th>
                    <th>Mata Pelajaran</th>
                    <th>Deadline</th>
                    <th>Terkumpul</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $tugas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td>
                        <div style="font-weight:600;"><?php echo e($t->judul); ?></div>
                        <?php if($t->deskripsi): ?>
                        <div style="font-size:12px;color:var(--text-muted);"><?php echo e(Str::limit($t->deskripsi, 50)); ?></div>
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($t->kelas->nama_kelas ?? '-'); ?></td>
                    <td><?php echo e($t->mataPelajaran->nama ?? '-'); ?></td>
                    <td>
                        <?php if($t->deadline): ?>
                            <span style="color:<?php echo e($t->isTerlambat() ? 'var(--danger)' : 'var(--text-primary)'); ?>;font-size:13px;">
                                <?php echo e($t->deadline->format('d/m/Y H:i')); ?>

                            </span>
                        <?php else: ?>
                            <span style="color:var(--text-muted);">-</span>
                        <?php endif; ?>
                    </td>
                    <td><span class="badge badge-blue"><?php echo e($t->pengumpulan->count()); ?> siswa</span></td>
                    <td>
                        <?php $colors = ['aktif'=>'badge-green','selesai'=>'badge-light','draft'=>'badge-light']; ?>
                        <span class="badge <?php echo e($colors[$t->status] ?? 'badge-light'); ?>"><?php echo e(ucfirst($t->status)); ?></span>
                    </td>
                    <td>
                        <div class="action-btns">
                            <a href="<?php echo e(route('guru.tugas.penilaian', $t)); ?>"
                               class="btn-icon"
                               style="background:#f3e5f5;color:var(--purple);"
                               title="Penilaian">
                                <i class="fas fa-star"></i>
                            </a>

                            <?php if($t->pengumpulan->count() > 0): ?>
                                <a href="<?php echo e(route('guru.tugas.show', $t)); ?>"
                                   class="btn-icon"
                                   style="background:#e0f2fe;color:#0284c7;"
                                   title="Ada <?php echo e($t->pengumpulan->count()); ?> siswa sudah mengumpulkan — tidak bisa diedit">
                                    <i class="fas fa-eye"></i>
                                </a>
                            <?php else: ?>
                                <a href="<?php echo e(route('guru.tugas.edit', $t)); ?>"
                                   class="btn-icon"
                                   title="Edit">
                                    <i class="fas fa-pen"></i>
                                </a>
                            <?php endif; ?>

                            <form action="<?php echo e(route('guru.tugas.destroy', $t)); ?>" method="POST" style="display:inline;">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button class="btn-icon btn-delete"
                                        data-confirm="Hapus tugas ini?"
                                        title="Hapus">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7" class="empty-row">
                        <i class="fas fa-inbox" style="font-size:24px;display:block;margin-bottom:8px;"></i>
                        Belum ada tugas.
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="pagination-wrapper"><?php echo e($tugas->links()); ?></div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.guru', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\PSI\Proyek Akhir\sistem-informasi-sd-negeri-sukorame-1\resources\views/guru/tugas/index.blade.php ENDPATH**/ ?>
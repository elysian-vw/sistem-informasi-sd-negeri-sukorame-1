<?php $__env->startSection('title', 'Pengumuman'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-header">
    <div>
        <h1 class="page-title">Pengumuman</h1>
        <p class="page-subtitle">Informasi terbaru dari sekolah</p>
    </div>
</div>

<div class="content-card" style="margin-bottom:16px;">
    <div class="table-toolbar">
        <form method="GET" style="display:flex;gap:10px;width:100%;">
            <select name="kategori" class="form-control" style="width:auto;">
                <option value="">Semua Kategori</option>
                <?php $__currentLoopData = $kategoriList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($k); ?>" <?php if(request('kategori')==$k): echo 'selected'; endif; ?>><?php echo e($k); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-search"></i> Filter</button>
            <a href="<?php echo e(route('wali.pengumuman.index')); ?>" class="btn btn-sm" style="background:var(--bg);color:var(--text-secondary);border:1px solid var(--border);">Reset</a>
        </form>
    </div>
</div>

<div class="content-card">
    <div>
        <?php $__empty_1 = true; $__currentLoopData = $pengumuman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <a href="<?php echo e(route('wali.pengumuman.show', $p)); ?>" style="text-decoration:none;display:block;">
            <div class="announcement-item" style="padding:16px 20px;">
                <div class="ann-icon"><i class="fas fa-megaphone"></i></div>
                <div style="flex:1;">
                    <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px;">
                        <?php if($p->kategori): ?>
                        <span class="badge badge-blue"><?php echo e($p->kategori); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="ann-title"><?php echo e($p->judul); ?></div>
                    <div style="font-size:13px;color:var(--text-secondary);margin:4px 0;"><?php echo e(Str::limit(strip_tags($p->isi), 100)); ?></div>
                    <div class="ann-meta"><i class="fas fa-user"></i> <?php echo e($p->user->name); ?> &nbsp;·&nbsp; <i class="fas fa-clock"></i> <?php echo e($p->created_at->isoFormat('D MMMM Y')); ?></div>
                </div>
                <i class="fas fa-chevron-right" style="color:var(--text-muted);"></i>
            </div>
        </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="empty-state" style="padding:40px;">Tidak ada pengumuman saat ini.</div>
        <?php endif; ?>
    </div>
    <div class="pagination-wrapper"><?php echo e($pengumuman->links()); ?></div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.wali', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\PSI\Proyek Akhir\sistem-informasi-sd-negeri-sukorame-1\resources\views/wali/pengumuman/index.blade.php ENDPATH**/ ?>
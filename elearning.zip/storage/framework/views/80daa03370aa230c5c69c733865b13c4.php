<nav class="navbar">
    <div class="navbar-left">
        
        <button class="hamburger-btn" id="sidebarToggle" aria-label="Buka menu">
            <span class="bar"></span>
            <span class="bar"></span>
            <span class="bar"></span>
        </button>
    </div>

    <div class="navbar-right">
        <span><?php echo e(auth()->user()->name ?? 'User'); ?></span>
    </div>
</nav><?php /**PATH D:\laragon\www\PSI\Proyek Akhir\sistem-informasi-sd-negeri-sukorame-1\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Absensi Saya'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-header">
    <div>
        <h1 class="page-title">Absensi Saya</h1>
        <p class="page-subtitle">Riwayat kehadiran sekolah</p>
    </div>
</div>

<div class="content-card" style="margin-bottom:16px;">
    <div class="table-toolbar">
        <form method="GET" style="display:flex;gap:10px;flex-wrap:wrap;">
            <select name="bulan" class="form-control" style="width:auto;">
                <?php $__currentLoopData = range(1,12); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($b); ?>" <?php if($bulan==$b): echo 'selected'; endif; ?>><?php echo e(\Carbon\Carbon::create()->month($b)->isoFormat('MMMM')); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <select name="tahun" class="form-control" style="width:auto;">
                <?php $__currentLoopData = range(now()->year-1, now()->year); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($y); ?>" <?php if($tahun==$y): echo 'selected'; endif; ?>><?php echo e($y); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-search"></i> Tampilkan</button>
        </form>
    </div>
</div>

<div class="stats-grid" style="grid-template-columns:repeat(5,1fr);margin-bottom:24px;">
    <div class="stat-card stat-green">
        <div class="stat-icon"><i class="fas fa-check-circle"></i></div>
        <div><span class="stat-number"><?php echo e($rekap['hadir']); ?></span><span class="stat-label">Hadir</span></div>
    </div>
    <div class="stat-card stat-orange">
        <div class="stat-icon"><i class="fas fa-hospital"></i></div>
        <div><span class="stat-number"><?php echo e($rekap['sakit']); ?></span><span class="stat-label">Sakit</span></div>
    </div>
    <div class="stat-card stat-blue">
        <div class="stat-icon"><i class="fas fa-file-lines"></i></div>
        <div><span class="stat-number"><?php echo e($rekap['izin']); ?></span><span class="stat-label">Izin</span></div>
    </div>
    <div class="stat-card stat-purple">
        <div class="stat-icon"><i class="fas fa-user-times"></i></div>
        <div><span class="stat-number"><?php echo e($rekap['alpha']); ?></span><span class="stat-label">Alpha</span></div>
    </div>
    <div class="stat-card" style="border-color:#0f172a;">
        <div class="stat-icon" style="background:#f0f4f8;color:#0f172a;"><i class="fas fa-percent"></i></div>
        <div><span class="stat-number"><?php echo e($rekap['persentase']); ?>%</span><span class="stat-label">Kehadiran</span></div>
    </div>
</div>

<div class="content-card">
    <div class="card-header">
        <h3><i class="fas fa-calendar-check" style="color:var(--primary);margin-right:8px;"></i>Detail Absensi</h3>
    </div>
    <div class="table-responsive">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Tanggal</th>
                    <th>Hari</th>
                    <th>Status</th>
                    <th>Keterangan</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $absensi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $badge = ['hadir'=>'badge-green','sakit'=>'badge-light','izin'=>'badge-blue','alpha'=>'badge-light'];
                    $color = ['hadir'=>'','sakit'=>'color:var(--warning);','izin'=>'','alpha'=>'color:var(--danger);'];
                ?>
                <tr>
                    <td style="font-weight:600;"><?php echo e($a->tanggal->format('d/m/Y')); ?></td>
                    <td><?php echo e($a->tanggal->isoFormat('dddd')); ?></td>
                    <td>
                        <span class="badge <?php echo e($badge[$a->status]??'badge-light'); ?>" style="<?php echo e($color[$a->status]??''); ?>">
                            <?php echo e(ucfirst($a->status)); ?>

                        </span>
                    </td>
                    <td style="color:var(--text-secondary);"><?php echo e($a->keterangan ?? '-'); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="4" class="empty-row">Tidak ada data absensi untuk periode ini.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.siswa', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\PSI\Proyek Akhir\sistem-informasi-sd-negeri-sukorame-1\resources\views/siswa/absensi/index.blade.php ENDPATH**/ ?>
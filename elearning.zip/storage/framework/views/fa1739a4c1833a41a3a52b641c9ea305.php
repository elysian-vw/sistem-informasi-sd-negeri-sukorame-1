<?php $__env->startSection('title', 'Penilaian Rapor'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h1 class="page-title">Penilaian Rapor (Akhir)</h1>
    <p class="page-subtitle">Pilih Mata Pelajaran untuk Kelas <?php echo e($kelas->nama_kelas); ?></p>
</div>

<?php if(session('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<div style="display:grid;grid-template-columns:repeat(auto-fill, minmax(250px, 1fr));gap:20px;">
    <?php $__currentLoopData = $mapel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="content-card" style="text-align:center; padding:30px 20px;">
        <div style="width:60px; height:60px; background:#eff6ff; color:var(--primary); border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:24px; margin:0 auto 16px;">
            <i class="fas fa-book-open"></i>
        </div>
        <h3 style="margin:0 0 8px 0; font-size:18px;"><?php echo e($m->nama); ?></h3>
        <p style="color:var(--text-muted); font-size:13px; margin-bottom:20px;">Input nilai Tugas, UTS, dan UAS</p>
        
        <a href="<?php echo e(route('guru.nilai.input', $m->id)); ?>" class="btn btn-primary" style="width:100%;">
            <i class="fas fa-edit"></i> Input Nilai
        </a>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.guru', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\PSI\Proyek Akhir\sistem-informasi-sd-negeri-sukorame-1\resources\views/guru/nilai/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Mata Pelajaran'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h1 class="page-title">Mata Pelajaran</h1>
</div>

<?php if(session('success')): ?>
    <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo e(session('success')); ?></div>
<?php endif; ?>


<div class="stat-row">
    <div class="stat-mini">
        <span class="stat-mini-label">Total Mata Pelajaran</span>
        <span class="stat-mini-value"><?php echo e($totalMapel); ?></span>
    </div>
    <div class="stat-mini">
        <span class="stat-mini-label">Mapel Wajib</span>
        <span class="stat-mini-value"><?php echo e($mapelWajib); ?></span>
    </div>
    <div class="stat-mini">
        <span class="stat-mini-label">Muatan Lokal</span>
        <span class="stat-mini-value"><?php echo e($muatanLokal); ?></span>
    </div>
</div>

<div class="main-grid">
    
    <div class="content-card">
        
        <div class="toolbar">
            <form method="GET" action="<?php echo e(route('admin.mata-pelajaran.index')); ?>" class="toolbar-filters">
                <input type="text" name="cari" value="<?php echo e(request('cari')); ?>" class="form-control" placeholder="Cari nama / kode...">

                <select name="jenis" class="form-control">
                    <option value="">Jenis Mapel</option>
                    <option value="wajib" <?php echo e(request('jenis') == 'wajib' ? 'selected' : ''); ?>>Wajib</option>
                    <option value="mulok" <?php echo e(request('jenis') == 'mulok' ? 'selected' : ''); ?>>Muatan Lokal</option>
                </select>

                <select name="tingkat" class="form-control">
                    <option value="">Tingkat Kelas</option>
                    <?php for($i = 1; $i <= 6; $i++): ?>
                        <option value="<?php echo e($i); ?>" <?php echo e(request('tingkat') == $i ? 'selected' : ''); ?>>Kelas <?php echo e($i); ?></option>
                    <?php endfor; ?>
                </select>

                <select name="status" class="form-control">
                    <option value="">Status</option>
                    <option value="aktif" <?php echo e(request('status') == 'aktif' ? 'selected' : ''); ?>>Aktif</option>
                    <option value="tidak_aktif" <?php echo e(request('status') == 'tidak_aktif' ? 'selected' : ''); ?>>Tidak Aktif</option>
                </select>

                <button type="submit" class="btn btn-secondary"><i class="fas fa-search"></i></button>
                <?php if(request('cari') || request('jenis') || request('tingkat') || request('status')): ?>
                    <a href="<?php echo e(route('admin.mata-pelajaran.index')); ?>" class="btn btn-secondary">
                        <i class="fas fa-times"></i>
                    </a>
                <?php endif; ?>
            </form>
        </div>

        
        <div class="table-wrapper">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Mapel</th>
                        <th>Jenis</th>
                        <th>Kelas</th>
                        <th>KKM</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $mapel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($mapel->firstItem() + $i); ?></td>
                            <td>
                                <div class="mapel-info">
                                    <span class="mapel-kode"><?php echo e($m->kode); ?></span>
                                    <span class="mapel-nama"><?php echo e($m->nama); ?></span>
                                    <?php if($m->guru): ?>
                                        <span class="mapel-guru"><i class="fas fa-chalkboard-teacher"></i> <?php echo e($m->guru->user?->name); ?></span>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td>
                                <span class="badge <?php echo e($m->jenis === 'wajib' ? 'badge-blue' : 'badge-orange'); ?>">
                                    <?php echo e($m->jenis === 'wajib' ? 'Wajib' : 'Mulok'); ?>

                                </span>
                            </td>
                            <td>Kelas <?php echo e($m->tingkat); ?></td>
                            <td><?php echo e($m->kkm); ?></td>
                            <td>
                                <span class="badge <?php echo e($m->status === 'aktif' ? 'badge-success' : 'badge-danger'); ?>">
                                    <?php echo e($m->status === 'aktif' ? 'Aktif' : 'Tidak Aktif'); ?>

                                </span>
                            </td>
                            <td>
                                <div class="action-btns">
                                    <button class="btn-icon btn-edit" title="Edit"
                                        onclick="openModalEdit(<?php echo e(json_encode($m)); ?>)">
                                        <i class="fas fa-pencil-alt"></i>
                                    </button>
                                    <form action="<?php echo e(route('admin.mata-pelajaran.destroy', $m->id)); ?>" method="POST"
                                        onsubmit="return confirm('Hapus mata pelajaran <?php echo e($m->nama); ?>?')">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn-icon btn-delete" title="Hapus">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="empty-state">Belum ada data mata pelajaran.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if($mapel->hasPages()): ?>
            <div class="pagination-wrap"><?php echo e($mapel->links()); ?></div>
        <?php endif; ?>
    </div>

    
    <div class="content-card form-card">
        <div class="form-card-header">
            <h3 id="form-title">Tambah Mata Pelajaran</h3>
        </div>
        <form id="form-mapel" method="POST" action="<?php echo e(route('admin.mata-pelajaran.store')); ?>">
            <?php echo csrf_field(); ?>
            <span id="method-field"></span>

            <div class="form-group">
                <label class="form-label">Kode <span class="required">*</span></label>
                <input type="text" name="kode" id="f-kode" class="form-control" placeholder="cth: MTK1, BIN2" required>
            </div>

            <div class="form-group">
                <label class="form-label">Nama Mata Pelajaran <span class="required">*</span></label>
                <input type="text" name="nama" id="f-nama" class="form-control" required>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Jenis <span class="required">*</span></label>
                    <select name="jenis" id="f-jenis" class="form-control" required>
                        <option value="wajib">Wajib</option>
                        <option value="mulok">Muatan Lokal</option>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Tingkat Kelas <span class="required">*</span></label>
                    <select name="tingkat" id="f-tingkat" class="form-control" required>
                        <option value="">-- Pilih --</option>
                        <?php for($i = 1; $i <= 6; $i++): ?>
                            <option value="<?php echo e($i); ?>">Kelas <?php echo e($i); ?></option>
                        <?php endfor; ?>
                    </select>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">KKM <span class="required">*</span></label>
                    <input type="number" name="kkm" id="f-kkm" class="form-control" value="70" min="0" max="100" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Status <span class="required">*</span></label>
                    <select name="status" id="f-status" class="form-control" required>
                        <option value="aktif">Aktif</option>
                        <option value="tidak_aktif">Tidak Aktif</option>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label class="form-label">Pengampu (Guru)</label>
                <select name="guru_id" id="f-guru" class="form-control">
                    <option value="">-- Pilih Guru --</option>
                    <?php $__currentLoopData = $guruList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($g->id); ?>"><?php echo e($g->user?->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="form-actions">
                <button type="button" class="btn btn-secondary" id="btn-reset" onclick="resetForm()">
                    <i class="fas fa-times"></i> Reset
                </button>
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> Simpan
                </button>
            </div>
        </form>
    </div>
</div>

<style>
/* Layout */
.main-grid { display:grid; grid-template-columns: 1fr 320px; gap:20px; align-items:start; }
@media(max-width:900px) { .main-grid { grid-template-columns:1fr; } }

/* Stat */
.stat-row { display:flex; gap:16px; margin-bottom:20px; flex-wrap:wrap; }
.stat-mini { background:#fff; border:1px solid #e5e7eb; border-radius:10px; padding:16px 24px; min-width:160px; display:flex; flex-direction:column; gap:4px; flex:1; }
.stat-mini-label { font-size:12.5px; color:#6b7280; font-weight:500; }
.stat-mini-value { font-size:26px; font-weight:700; color:#111827; }

/* Toolbar */
.toolbar { padding:16px 20px; border-bottom:1px solid #f3f4f6; }
.toolbar-filters { display:flex; gap:8px; flex-wrap:wrap; align-items:center; }
.toolbar-filters .form-control { height:36px; font-size:13px; }
.toolbar-filters input { min-width:160px; }
.toolbar-filters select { min-width:130px; }

/* Table */
.table-wrapper { overflow-x:auto; }
.data-table { width:100%; border-collapse:collapse; font-size:13.5px; }
.data-table th { background:#f9fafb; padding:11px 16px; text-align:left; font-size:12px; font-weight:600; text-transform:uppercase; letter-spacing:.04em; color:#6b7280; border-bottom:1px solid #e5e7eb; white-space:nowrap; }
.data-table td { padding:12px 16px; border-bottom:1px solid #f3f4f6; vertical-align:middle; color:#374151; }
.data-table tbody tr:hover { background:#f9fafb; }

.mapel-info { display:flex; flex-direction:column; gap:2px; }
.mapel-kode { font-size:11px; font-weight:600; color:#9ca3af; text-transform:uppercase; }
.mapel-nama { font-weight:500; color:#111827; }
.mapel-guru { font-size:12px; color:#6b7280; }

.badge { display:inline-flex; padding:3px 10px; border-radius:20px; font-size:11.5px; font-weight:500; }
.badge-success { background:#dcfce7; color:#15803d; }
.badge-danger  { background:#fee2e2; color:#b91c1c; }
.badge-blue    { background:#dbeafe; color:#1d4ed8; }
.badge-orange  { background:#ffedd5; color:#c2410c; }

.action-btns { display:flex; gap:6px; }
.btn-icon { width:30px; height:30px; border:none; border-radius:6px; cursor:pointer; display:flex; align-items:center; justify-content:center; font-size:12px; transition:all .15s; }
.btn-edit { background:#eff6ff; color:#2563eb; }
.btn-edit:hover { background:#dbeafe; }
.btn-delete { background:#fef2f2; color:#dc2626; }
.btn-delete:hover { background:#fee2e2; }

.empty-state { text-align:center; color:#9ca3af; padding:40px; }
.pagination-wrap { padding:16px 20px; border-top:1px solid #f3f4f6; }

/* Form Card */
.form-card { padding:0; }
.form-card-header { padding:16px 20px; border-bottom:1px solid #f3f4f6; }
.form-card-header h3 { font-size:14px; font-weight:600; color:#111827; margin:0; }
.form-card form { padding:20px; }

.form-row { display:flex; gap:12px; }
.form-row .form-group { flex:1; }
.form-group { margin-bottom:14px; }
.form-label { display:block; font-size:13px; font-weight:500; color:#374151; margin-bottom:5px; }
.required { color:#ef4444; }
.form-control { width:100%; padding:8px 12px; border:1px solid #d1d5db; border-radius:8px; font-size:13.5px; color:#111827; background:#fff; box-sizing:border-box; transition:border-color .2s,box-shadow .2s; }
.form-control:focus { outline:none; border-color:#2563eb; box-shadow:0 0 0 3px rgba(37,99,235,.1); }
.form-actions { display:flex; gap:8px; justify-content:flex-end; margin-top:8px; }

.alert { padding:12px 16px; border-radius:8px; margin-bottom:20px; font-size:14px; display:flex; align-items:center; gap:8px; }
.alert-success { background:#f0fdf4; color:#15803d; border:1px solid #bbf7d0; }

/* Edit mode indicator */
.form-card-header.edit-mode { background:#fffbeb; }
.form-card-header.edit-mode h3 { color:#92400e; }
</style>

<script>
function openModalEdit(mapel) {
    document.getElementById('form-title').textContent = 'Edit Mata Pelajaran';
    document.getElementById('form-mapel').action = `/admin/mata-pelajaran/${mapel.id}`;
    document.getElementById('method-field').innerHTML = '<input type="hidden" name="_method" value="PUT">';
    document.querySelector('.form-card-header').classList.add('edit-mode');

    document.getElementById('f-kode').value    = mapel.kode ?? '';
    document.getElementById('f-nama').value    = mapel.nama ?? '';
    document.getElementById('f-jenis').value   = mapel.jenis ?? 'wajib';
    document.getElementById('f-tingkat').value = mapel.tingkat ?? '';
    document.getElementById('f-kkm').value     = mapel.kkm ?? 70;
    document.getElementById('f-status').value  = mapel.status ?? 'aktif';
    document.getElementById('f-guru').value    = mapel.guru_id ?? '';

    // Scroll ke form
    document.querySelector('.form-card').scrollIntoView({ behavior: 'smooth' });
}

function resetForm() {
    document.getElementById('form-title').textContent = 'Tambah Mata Pelajaran';
    document.getElementById('form-mapel').action = '<?php echo e(route("admin.mata-pelajaran.store")); ?>';
    document.getElementById('method-field').innerHTML = '';
    document.querySelector('.form-card-header').classList.remove('edit-mode');
    document.getElementById('form-mapel').reset();
    document.getElementById('f-kkm').value = 70;
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\PSI\Proyek Akhir\sistem-informasi-sd-negeri-sukorame-1\resources\views/admin/mata-pelajaran/index.blade.php ENDPATH**/ ?>
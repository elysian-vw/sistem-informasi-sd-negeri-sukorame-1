<?php $__env->startSection('title', 'Tambah Materi'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <div style="display:flex;align-items:center;gap:12px;">
        <a href="<?php echo e(route('guru.materi.index')); ?>" class="btn-back">
            <i class="fas fa-arrow-left"></i>
        </a>
        <div>
            <h1 class="page-title">Tambah Materi</h1>
            <p class="page-subtitle">Unggah atau bagikan materi pembelajaran</p>
        </div>
    </div>
</div>

<div style="display:grid;grid-template-columns:1fr 300px;gap:20px;align-items:start;">

    
    <form action="<?php echo e(route('guru.materi.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <div class="content-card">
            <div class="card-header">
                <h3><i class="fas fa-book" style="color:var(--primary);margin-right:8px;"></i>Informasi Materi</h3>
            </div>
            <div class="card-body" style="display:flex;flex-direction:column;gap:18px;">

                
                <div class="form-group">
                    <label class="form-label">Judul Materi <span class="required">*</span></label>
                    <input type="text" name="judul" value="<?php echo e(old('judul')); ?>"
                           class="form-input <?php $__errorArgs = ['judul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           placeholder="Contoh: Pengenalan Bilangan Bulat">
                    <?php $__errorArgs = ['judul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="form-error" style="color:red; font-size:12px; margin-top:4px;"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div class="form-group">
                    <label class="form-label">Deskripsi</label>
                    <textarea name="deskripsi" rows="3"
                              class="form-input <?php $__errorArgs = ['deskripsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                              placeholder="Penjelasan singkat tentang materi ini..."><?php echo e(old('deskripsi')); ?></textarea>
                    <?php $__errorArgs = ['deskripsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="form-error" style="color:red; font-size:12px; margin-top:4px;"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">
                    <div class="form-group">
                        <label class="form-label">Mata Pelajaran <span class="required">*</span></label>
                        <select name="mata_pelajaran_id"
                                class="form-input <?php $__errorArgs = ['mata_pelajaran_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <option value="">-- Pilih Mapel --</option>
                            <?php $__currentLoopData = $mapel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($mp->id); ?>" <?php echo e(old('mata_pelajaran_id') == $mp->id ? 'selected' : ''); ?>>
                                    <?php echo e($mp->nama); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['mata_pelajaran_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="form-error" style="color:red; font-size:12px; margin-top:4px;"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Kelas <span class="required">*</span></label>
                        <?php if($kelas->count() === 1): ?>
                            
                            <select name="kelas_id"
                                    class="form-input"
                                    style="background-color:#f8f9fa;cursor:not-allowed;pointer-events:none;">
                                <option value="<?php echo e($kelas->first()->id); ?>" selected>
                                    Kelas <?php echo e($kelas->first()->nama_kelas); ?> (Kelas Anda)
                                </option>
                            </select>
                            <div style="font-size:11px;color:var(--text-muted);margin-top:4px;">
                                * Terkunci pada kelas yang Anda ajar.
                            </div>
                        <?php else: ?>
                            
                            <select name="kelas_id"
                                    class="form-input <?php $__errorArgs = ['kelas_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <option value="">-- Pilih Kelas --</option>
                                <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($k->id); ?>" <?php echo e(old('kelas_id') == $k->id ? 'selected' : ''); ?>>
                                        Kelas <?php echo e($k->nama_kelas); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['kelas_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="form-error" style="color:red;font-size:12px;margin-top:4px;"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <?php endif; ?>
                    </div>
                </div>

                
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px; background:#f8fafc; padding:16px; border-radius:8px; border:1px solid #e2e8f0;">
                    <div class="form-group" style="margin-bottom: 0;">
                        <label class="form-label">Kategori <span class="required">*</span></label>
                        <select name="tipe" id="tipeKategori" class="form-input <?php $__errorArgs = ['tipe'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <option value="materi" <?php echo e(old('tipe') == 'materi' ? 'selected' : ''); ?>>Materi Pembelajaran</option>
                            <option value="tugas" <?php echo e(old('tipe') == 'tugas' ? 'selected' : ''); ?>>Tugas Siswa</option>
                            <option value="uts" <?php echo e(old('tipe') == 'uts' ? 'selected' : ''); ?>>UTS</option>
                            <option value="uas" <?php echo e(old('tipe') == 'uas' ? 'selected' : ''); ?>>UAS</option>
                        </select>
                        <?php $__errorArgs = ['tipe'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="form-error" style="color:red; font-size:12px; margin-top:4px;"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group" id="deadlineBox" style="display:none; margin-bottom: 0;">
                        <label class="form-label">Batas Waktu (Deadline)</label>
                        <input type="datetime-local" name="deadline" value="<?php echo e(old('deadline')); ?>" class="form-input">
                    </div>
                </div>

                
                <div class="form-group">
                    <label class="form-label">Format Media <span class="required">*</span></label>
                    <div class="tipe-selector">
                        <?php $__currentLoopData = ['file' => ['label'=>'File Dokumen','icon'=>'fa-file-alt'], 'link' => ['label'=>'Tautan (Link)','icon'=>'fa-link']]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val => $cfg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <label class="tipe-option <?php echo e(old('format_media', 'file') == $val ? 'active' : ''); ?>" for="format_<?php echo e($val); ?>">
                            <input type="radio" name="format_media" id="format_<?php echo e($val); ?>" value="<?php echo e($val); ?>"
                                   <?php echo e(old('format_media', 'file') == $val ? 'checked' : ''); ?>

                                   onchange="toggleTipeInput(this)">
                            <i class="fas <?php echo e($cfg['icon']); ?>"></i>
                            <span><?php echo e($cfg['label']); ?></span>
                        </label>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php $__errorArgs = ['format_media'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="form-error" style="color:red; font-size:12px; margin-top:4px;"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div id="input-file" class="form-group">
                    <label class="form-label">Upload File</label>
                    <div class="file-drop-area">
                        <i class="fas fa-cloud-upload-alt" style="font-size:28px;color:var(--primary);opacity:.6;margin-bottom:8px;"></i>
                        <div style="font-size:13px;color:var(--text-muted);margin-bottom:10px;">
                            Seret file ke sini atau klik untuk memilih
                        </div>
                        <input type="file" name="file" id="fileInput"
                               class="<?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               accept=".pdf,.doc,.docx,.ppt,.pptx,.xls,.xlsx,.zip"
                               onchange="showFileName(this)">
                        <div id="file-name" style="margin-top:8px;font-size:12px;color:var(--primary);font-weight:600;"></div>
                        <div style="font-size:11px;color:var(--text-muted);margin-top:4px;">PDF, Word, PowerPoint, Excel, ZIP — maks. 20 MB</div>
                    </div>
                    <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="form-error" style="color:red; font-size:12px; margin-top:4px;"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div id="input-link" class="form-group" style="display:none;">
                    <label class="form-label">URL Tautan</label>
                    <div style="position:relative;">
                        <i class="fas fa-link" style="position:absolute;left:12px;top:50%;transform:translateY(-50%);color:var(--text-muted);font-size:13px;"></i>
                        <input type="url" name="link_video" value="<?php echo e(old('link_video')); ?>"
                               class="form-input <?php $__errorArgs = ['link_video'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               style="padding-left:36px;"
                               placeholder="https://...">
                    </div>
                    <?php $__errorArgs = ['link_video'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="form-error" style="color:red; font-size:12px; margin-top:4px;"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

            </div>

            <div class="card-footer" style="display:flex;gap:10px;padding:16px 20px;border-top:1px solid var(--border);">
                <button type="submit" class="btn-primary-action">
                    <i class="fas fa-save"></i> Simpan Materi
                </button>
                <a href="<?php echo e(route('guru.materi.index')); ?>" class="btn-secondary-action">Batal</a>
            </div>
        </div>
    </form>

    
    <div class="content-card" style="position:sticky;top:20px;">
        <div class="card-header">
            <h3><i class="fas fa-info-circle" style="color:var(--primary);margin-right:8px;"></i>Panduan</h3>
        </div>
        <div class="card-body">
            <div class="guide-item">
                <div class="guide-icon" style="background:#e8f0fe;color:var(--primary);">
                    <i class="fas fa-file-alt"></i>
                </div>
                <div>
                    <div style="font-weight:600;font-size:13px;margin-bottom:2px;">File Dokumen</div>
                    <div style="font-size:12px;color:var(--text-muted);">Unggah PDF, Word, PowerPoint, atau ZIP.</div>
                </div>
            </div>
            <div class="guide-item">
                <div class="guide-icon" style="background:#fce8e6;color:var(--danger);">
                    <i class="fas fa-link"></i>
                </div>
                <div>
                    <div style="font-weight:600;font-size:13px;margin-bottom:2px;">Tautan (Link)</div>
                    <div style="font-size:12px;color:var(--text-muted);">Tautkan Google Drive, Docs, atau web lain.</div>
                </div>
            </div>
        </div>
    </div>

</div>

<?php $__env->startPush('scripts'); ?>
<script>
function toggleTipeInput(radio) {
    const tipe = radio.value;
    const fileDiv = document.getElementById('input-file');
    const linkDiv = document.getElementById('input-link');

    fileDiv.style.display = tipe === 'file' ? 'block' : 'none';
    linkDiv.style.display = tipe === 'link' ? 'block' : 'none';

    document.querySelectorAll('.tipe-option').forEach(l => l.classList.remove('active'));
    radio.closest('.tipe-option').classList.add('active');
}

function showFileName(input) {
    const display = document.getElementById('file-name');
    display.textContent = input.files[0] ? '📎 ' + input.files[0].name : '';
}

document.getElementById('tipeKategori').addEventListener('change', function() {
    document.getElementById('deadlineBox').style.display = this.value === 'materi' ? 'none' : 'block';
});

document.addEventListener('DOMContentLoaded', function() {
    const checkedMedia = document.querySelector('input[name="format_media"]:checked');
    if (checkedMedia) toggleTipeInput(checkedMedia);
    
    if (document.getElementById('tipeKategori').value !== 'materi') {
        document.getElementById('deadlineBox').style.display = 'block';
    }
});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.guru', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\PSI\Proyek Akhir\sistem-informasi-sd-negeri-sukorame-1\resources\views/guru/materi/create.blade.php ENDPATH**/ ?>